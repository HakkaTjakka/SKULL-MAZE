Examples for setting pallettes of blocks, setting sizes to change large areas of blocks based on input conditions (either player or mathmatically defined ones)

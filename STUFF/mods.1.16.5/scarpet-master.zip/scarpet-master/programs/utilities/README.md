Utilities for showing technical aspects of the game, often to help with farm design testing and showcase, and utilities to help check game/player interactions.
i.e., showing chunk loading, and measuring mob lifetimes

Programs for calculating math operations, and examples for min/max interation, heaps and hashes
